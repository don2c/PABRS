# Experimental Discussion Comparison

PABRS, ARPSSO, ESAS, Covercrypt, IB-CAKE, and Dobby do not evaluate the same artifact.

- **PABRS** evaluates an emulator of a policy-aware authorisation primitive.
- **ARPSSO** and **IB-CAKE** evaluate protocol-level cryptographic overhead.
- **ESAS** evaluates edge deployment feasibility.
- **Covercrypt** evaluates primitive-level KEM efficiency.
- **Dobby** evaluates end-to-end analytics latency in a two-server model.

## Expert comparison

**Dobby** has the strongest workload-based discussion. It reports 732 ms for 10,000 streams with one-condition policies, and about 2.3 s to 3.3 s for eight-condition policies. Its discussion is richer than PABRS on workload realism, but it studies a server-assisted analytics system.

**Covercrypt** has the clearest primitive benchmark. It reports about 0.5 ms encryption and about 1 ms decryption in classical use, and compares itself to slower post-quantum ABE baselines. Its discussion is stronger than PABRS on concrete primitive efficiency.

**ESAS** is strongest on deployment realism. It targets routers, publishers, and subscribers, and reports feasibility on Raspberry Pi 4 with PBC, OpenSSL, and Python.

**ARPSSO** is strongest on protocol integration. It discusses acceptable prototype overhead, compatibility, transparency, and deployment cost.

**IB-CAKE** is narrowest. It focuses on pairing efficiency and comparison with TFNS19, rather than policy-rich access control.

**PABRS** is broadest in metric coverage. It covers correctness, cost, scalability, and leakage proxies in one section. Its weakness is that the evidence is still emulator-level.
