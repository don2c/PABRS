# Benchmark Summary

## Main observations
- accepted_issuers: sign mean changed from 0.199 ms to 0.206 ms. Verify mean changed from 0.092 ms to 0.093 ms.
- policy_literals: sign mean changed from 0.152 ms to 0.422 ms. Verify mean changed from 0.089 ms to 0.105 ms.
- credentials_per_user: sign mean changed from 0.229 ms to 0.254 ms. Verify mean changed from 0.123 ms to 0.138 ms.
- slot_bound: sign mean changed from 0.166 ms to 0.263 ms. Verify mean changed from 0.060 ms to 0.143 ms.

## Attack results
- replay: rejection rate 100.0%.
- changed_context: rejection rate 100.0%.
- stale_epoch: rejection rate 100.0%.
- revoked_credential: rejection rate 100.0%.
- mixed_user_pooling: rejection rate 100.0%.
- wrong_issuer: rejection rate 100.0%.
- malformed_proof: rejection rate 100.0%.

## Scope
These results come from a functional emulator and synthetic workload harness. They do not represent pairing-based cryptographic microbenchmarks.