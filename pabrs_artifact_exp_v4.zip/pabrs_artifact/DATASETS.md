# Included Datasets

## Public data bundled in this artifact

- ABAC-Lab University
- ABAC-Lab Workforce
- ABAC-Lab Healthcare
- ABAC-Lab Project Management
- ABAC-Lab Edocument

These are stored in `data/public/abac_lab/` as `.abac` policy files.

## Public data referenced but not bundled

- UCI Amazon Access Samples

The manifest file records the source URL. This dataset was referenced in the evaluation design, but the raw file is not bundled in the current package.

## Synthetic CSV data bundled in this artifact

Stored in `data/synthetic/`:

- `case_manifest.csv`
- `descriptors.csv`
- `requests.csv`
- `users.csv`
- `credentials.csv`
